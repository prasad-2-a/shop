public class Board {
          
	/*write your member variables/constants here 

	For example:

	final int NUMROWS = 6;
	


	start writing your methods here. For example the constructor will look like


	public Board(Piece[][] oldBoard) {

	}
	
	public Piece getPiece(int row, int col) {
		
	}
	*/
  private  int NUMROWS;
  private  int NUMCOLS;

   Piece piece[]=new Piece[NUMROWS][NUMCOLS];
  for(int i=0;i<NUMROWS;i++)
    for(int j=0;j<NUMCOLS;j++)
     {
        Piece[i][j]=Piece.RED; 
        Piece[i][j]=Piece.BLACK; 
         Piece[i][j]=Piece.EMPTY;
     }

   public Board(Piece[][] oldBoard) {
       theBoard = oldBoard;
      
	}
  public Piece getPiece(int row, int col) {
	Piece lowerleft = getPiece(0,0);
	
	}
  public Piece[][] getPieceArray()
   {
     return Piece;
   }
 public int findFirstFreeRow(int column)
  {
   return 3;
  }
  public boolean isLegal(int nextMove)
 {
  return false;
 }
  public boolean existLegalMoves(){
 
    }
public Piece getWinner(){
 
}
void updateBoard(int moveChoice, Piece move)
{
}
public static Board GenerateEmptyBoard(){
}


  
    
  
}