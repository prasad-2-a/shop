//do not make any modifications to this file!

public interface Player {
	 int chooseMove(Board b, Piece turn);
}