import java.util.Scanner;

public class HumanPlayer implements Player {
	public int chooseMove(Board b, Piece turn) {
		//select a move here using a Scanner
          Scanner sc=new Scanner(System.in);
          int turn=sc.nextInt();
          if(turn>=0 && turn<=7)
              return turn;
	}

}