import java.util.Scanner;

public class ConnectFour {

	public static Piece currentTurn;

	public static void main(String[] args) {
		int acceptedPlayers = 0;		
		currentTurn = Piece.RED;

		Player p1 = promptForNextPlayer();	
		Player p2 = promptForNextPlayer();

		Board currentBoard = Board.GenerateEmptyBoard();

		while (currentBoard.getWinner() == Piece.EMPTY && currentBoard.existLegalMoves())
		{
			//after you write the printBoard() method in the warmup, and the getPieceArray() in the board class, uncomment the following line:
			//printBoard(currentBoard.getPieceArray());
			int moveChoice = -1;
			while (currentBoard.isLegal(moveChoice) == false) {
				if (currentTurn == Piece.RED) {
					moveChoice = p1.chooseMove(currentBoard, currentTurn);
				}
				else {
					moveChoice = p2.chooseMove(currentBoard, currentTurn);
				}
			}

			currentBoard.updateBoard(moveChoice, currentTurn);

			if (currentTurn == Piece.RED) {
				currentTurn = Piece.BLACK;
			}
			else {
				currentTurn = Piece.RED;
			}
		}

		//after you write the printBoard() method in the warmup, and the getPieceArray() in the board class, uncomment the following line:
		//printBoard(currentBoard.getPieceArray());

		//after you have written the getWinner() method inside of the Board class, uncomment the following line
		//System.out.println("The current winner is " + currentBoard.getWinner());
	}	

	public static Player promptForNextPlayer() {
		String input = "";
		Scanner s = new Scanner(System.in);
		while (true) {
			System.out.println("Would you like a human (h) or computer (c) player?");
			input = s.next(); 
			if (input.charAt(0) == 'h') {
				return new HumanPlayer();
			}

			if (input.charAt(0) == 'c') {
				return new ComputerPlayer();
			}
		}
	}
}