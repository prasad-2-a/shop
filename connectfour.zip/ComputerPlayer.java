import java.util.ArrayList;
import java.util.Stack;

public class ComputerPlayer implements Player {
	private final int MAX_PLY = 6;

	public int chooseMove(Board b, Piece turn) {
		return minimaxEvaluation(b, MAX_PLY, turn);
	}

	private int minimaxEvaluation(Board b, int plyLeft, Piece turn) {
		if (b.getWinner() != Piece.EMPTY) {
			return -1000;
		}

		if (b.existLegalMoves() == false) {
			return 0; // this number is a tie
		}		

		if (plyLeft <= 0) {
			return heuristic(b, turn);
		}

		int maxSoFar = -100000;

		ArrayList<Integer> allLegal = getAllLegalMoves(b);

		int bestMove = allLegal.get(0).intValue();

		for (Integer oneMove : allLegal) {
			Board latestBoard = new Board(b.getPieceArray());
			latestBoard.updateBoard(oneMove.intValue(), turn);
			int thisMoveValue;


			if (latestBoard.getWinner() != Piece.EMPTY) {
				thisMoveValue = 1000;
				maxSoFar = 1000 + 10 * plyLeft;
				bestMove = oneMove.intValue();
				break;
			}
			else {
				thisMoveValue = - minimaxEvaluation(latestBoard, plyLeft-1, getOppositeTurn(turn));
			}

			if (thisMoveValue > maxSoFar) {
				maxSoFar = thisMoveValue;
				bestMove = oneMove.intValue();
			}
		}

		if (plyLeft == MAX_PLY) {
			return bestMove;
		}
		else {
			return maxSoFar;
		}
	}

	//this method assumes that piece is either red or black and not empty
	private Piece getOppositeTurn(Piece turn) {
		if (turn == Piece.BLACK) {
			return Piece.RED;
		}
		else {
			return Piece.BLACK;
		}
	}

	private ArrayList<Integer> getAllLegalMoves(Board b) {
		ArrayList<Integer> allMoves = new ArrayList<Integer>();
		for (int i=0; i < b.NUMCOLS; i++) {
			if (b.isLegal(i)) {
				allMoves.add(new Integer(i));
			}
		}
		
		return allMoves;
	}

	public int heuristic(Board b, Piece turn) {

		//YOUR CODE GOES HERE.
		//NOTE: You may add other methods below that you find useful such as imminentWin() or getTotalTriples()
		return 0;		
	}


	//the following methods are 100% optional, but you may find them useful to write as you will repeat these computations many times

	//returns true if the input board b has an imminent win for the player "turn" . I.e. if turn has 3 in a row and can make a 4th move
	/*private boolean imminentWin(Board b, Piece turn) {
	}
	*/

	//returns the total number of 3 in a rows for player p. If requiredOpening is true then this filters out cases where it is blocked
	//by an opponents piece or the move is not yet playable because the column isn't yet filled enough to play here
	/*private int getTotalTriples(Board b, Piece p, boolean requiredOpening) {
	}*/


}