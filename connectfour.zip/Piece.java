//do not change this file

public enum Piece { RED, BLACK, EMPTY }
